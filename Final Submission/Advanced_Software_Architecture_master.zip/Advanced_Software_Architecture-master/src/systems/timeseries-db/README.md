# Influxdb setup

This is inspired by this article: [Set up Telegraf, InfluxDB and Grafana with Docker Compose](https://sweetcode.io/set-up-telegraf-influxdb-and-grafana-with-docker-compose/)
