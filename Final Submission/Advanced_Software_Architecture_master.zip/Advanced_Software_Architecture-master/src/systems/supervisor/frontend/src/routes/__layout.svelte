<script>
    import { link } from "svelte-routing";
</script>

<slot></slot>

<style>
    /* Add global styles or layout styles here */
</style>
