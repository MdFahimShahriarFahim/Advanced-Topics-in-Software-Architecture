/**
 * Convert paths to full for testing.
 */

import jetPaths from 'jet-paths';

import Paths from '@src/constants/Paths';


export default jetPaths(Paths);
