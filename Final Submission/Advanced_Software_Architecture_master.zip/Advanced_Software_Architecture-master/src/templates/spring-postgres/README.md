# Spring with Postgres
Spring with Postgres integration. 

## Development
Development is done using IntelliJ IDEA.

Useful commands:
* `mvn clean compile` Rebuild
* `mvn spring-boot:run` Run application

