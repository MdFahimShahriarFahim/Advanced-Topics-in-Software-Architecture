# Templates dir for different services
This is a directory with templates for the different types of services we need. You can take a programming language and then use this template that uses a framework with that programming language.

## Diagram
![Diagram of the infrastructure](.assets/diagram.png)
