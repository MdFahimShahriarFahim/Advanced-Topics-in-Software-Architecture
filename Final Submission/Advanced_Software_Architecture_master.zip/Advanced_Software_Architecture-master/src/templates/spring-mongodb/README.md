# Spring with MongoDB
Spring with MongoDB integration. 

## Development
Development is done using IntelliJ IDEA.

Useful commands:
* `mvn clean compile` Rebuild
* `mvn spring-boot:run` Run application

