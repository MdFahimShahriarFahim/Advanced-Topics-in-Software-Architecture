# Readme

The system can be run using the docker-compose file in `src/systems/docker-compose.yaml`.
